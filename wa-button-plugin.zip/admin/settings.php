<main class="wa-button">
  <h1>WhatsApp Floating Button</h1>

  <p>TODO: Settings form.</p>
</main>
