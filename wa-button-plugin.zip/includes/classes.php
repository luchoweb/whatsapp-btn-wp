<?php

require_once plugin_dir_path(__DIR__) . 'includes/class-db-migrations.php';
require_once plugin_dir_path(__DIR__) . 'includes/class-register-menu.php';
require_once plugin_dir_path(__DIR__) . 'includes/class-render-button.php';
